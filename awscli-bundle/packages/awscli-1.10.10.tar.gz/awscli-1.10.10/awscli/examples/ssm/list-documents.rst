**To list all the configuration documents in your account**

This example lists all the configuration documents in your account.

Command::

  aws ssm list-documents

Output::

 {
    "DocumentIdentifiers": [
        {
            "Name": "Config_2"
        }, 
        {
            "Name": "My_Config_Document"
        }
    ]
 }
