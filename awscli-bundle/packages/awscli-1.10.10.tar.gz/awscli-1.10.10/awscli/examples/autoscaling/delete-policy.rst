**To delete an Auto Scaling policy**

This example deletes the specified Auto Scaling policy::

	aws autoscaling delete-policy --auto-scaling-group-name my-auto-scaling-group --policy-name ScaleIn
